package com.liquidglass.nativecc.v2;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;

import java.io.File;
import java.io.FileWriter;

/** One-time dump of the real QS root view hierarchy so we can pick verified attach targets. */
final class ViewTreeDumper {
    private ViewTreeDumper() {}

    static void dump(View root, String label) {
        try {
            StringBuilder sb = new StringBuilder();
            walk(root, 0, 6, sb);
            DebugLogger.i("VIEW TREE [" + label + "] (depth<=6):\n" + sb);
            Context c = root.getContext();
            File f = new File(c.getFilesDir(), "lgcc_v2_viewtree_" + label + ".txt");
            try (FileWriter w = new FileWriter(f)) { w.write(sb.toString()); }
            DebugLogger.i("view tree saved: " + f.getAbsolutePath());
        } catch (Throwable t) {
            DebugLogger.e("view tree dump", t);
        }
    }

    private static void walk(View v, int depth, int max, StringBuilder sb) {
        for (int i = 0; i < depth; i++) sb.append("  ");
        sb.append(v.getClass().getName());
        int id = v.getId();
        if (id != View.NO_ID) {
            try { sb.append(" #").append(v.getResources().getResourceEntryName(id)); }
            catch (Throwable ignored) { sb.append(" #0x").append(Integer.toHexString(id)); }
        }
        sb.append(" [").append(v.getWidth()).append("x").append(v.getHeight()).append("]")
          .append(v.getVisibility() == View.VISIBLE ? "" : " (not visible)").append('\n');
        if (v instanceof ViewGroup && depth < max) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) walk(g.getChildAt(i), depth + 1, max, sb);
        }
    }
}
