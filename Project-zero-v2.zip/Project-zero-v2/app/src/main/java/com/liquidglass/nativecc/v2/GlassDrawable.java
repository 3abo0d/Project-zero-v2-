package com.liquidglass.nativecc.v2;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

/**
 * Glass edge material drawn as a View FOREGROUND over the native tile/slider (which keeps the
 * native Fluid Glass backdrop). Layers: directional rim light, inner refraction band, top gloss.
 * Does not intercept touches and never alters the native background.
 */
final class GlassDrawable extends Drawable {
    private final Paint rim = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint inner = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint gloss = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();

    private float radiusPx = -1f;   // < 0: derive from bounds
    private float strokePx = 3f;
    private int rimA, innerA, glossA;
    private float angleDeg = 315f;
    private int alpha = 255;

    GlassDrawable() {
        rim.setStyle(Paint.Style.STROKE);
        inner.setStyle(Paint.Style.STROKE);
        gloss.setStyle(Paint.Style.FILL);
    }

    void update(float radiusPx, float strokePx, GlassStyle s) {
        this.radiusPx = radiusPx;
        this.strokePx = strokePx;
        this.rimA = s.rim * 255 / 100;
        this.innerA = s.inner * 255 / 100;
        this.glossA = s.gloss * 255 / 100;
        this.angleDeg = s.angle;
        rebuild();
        invalidateSelf();
    }

    @Override
    protected void onBoundsChange(Rect bounds) {
        rebuild();
    }

    private void rebuild() {
        Rect b = getBounds();
        if (b.isEmpty()) return;
        float w = b.width(), h = b.height();
        float cx = b.exactCenterX(), cy = b.exactCenterY();
        double a = Math.toRadians(angleDeg);
        float dx = (float) Math.sin(a), dy = (float) -Math.cos(a); // toward the light
        float ext = (Math.abs(dx) * w + Math.abs(dy) * h) / 2f;
        float x0 = cx + dx * ext, y0 = cy + dy * ext, x1 = cx - dx * ext, y1 = cy - dy * ext;

        rim.setStrokeWidth(strokePx);
        rim.setShader(new LinearGradient(x0, y0, x1, y1,
                new int[]{Color.argb(rimA, 255, 255, 255), Color.argb(rimA / 8, 255, 255, 255),
                        Color.argb(rimA * 45 / 100, 255, 255, 255)},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));

        inner.setStrokeWidth(strokePx * 1.6f);
        inner.setShader(new LinearGradient(x0, y0, x1, y1,
                new int[]{Color.argb(innerA, 255, 255, 255), Color.argb(0, 255, 255, 255),
                        Color.argb(innerA / 2, 255, 255, 255)},
                new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));

        gloss.setShader(new LinearGradient(x0, y0, cx, cy,
                Color.argb(glossA, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP));
    }

    @Override
    public void draw(Canvas c) {
        Rect b = getBounds();
        if (b.isEmpty()) return;
        float maxR = Math.min(b.width(), b.height()) / 2f;
        float rad = radiusPx >= 0 ? Math.min(radiusPx, maxR) : maxR * 0.9f;
        rim.setAlpha(alpha);
        inner.setAlpha(alpha);
        gloss.setAlpha(alpha);

        float half = strokePx / 2f;
        r.set(b.left + half, b.top + half, b.right - half, b.bottom - half);
        float rr = Math.max(0f, rad - half);
        c.drawRoundRect(r, rr, rr, gloss);          // gloss fills the shape
        c.drawRoundRect(r, rr, rr, rim);            // crisp rim light

        float off = strokePx * 1.9f;                // inner refraction band, inside the rim
        r.set(b.left + off, b.top + off, b.right - off, b.bottom - off);
        float ri = Math.max(0f, rad - off);
        c.drawRoundRect(r, ri, ri, inner);
    }

    @Override public void setAlpha(int a) { alpha = a; invalidateSelf(); }
    @Override public void setColorFilter(ColorFilter cf) { }
    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}
