package com.liquidglass.nativecc.v2;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;

/**
 * Our glass material. Two uses:
 *  - kinds INACTIVE / ACTIVE / UNAVAILABLE / CARD: a full background that REPLACES the native
 *    baked fluid-glass bitmaps (body fill + rim light + inner refraction band + gloss).
 *  - kind OVERLAY: edge layers only, drawn as a View foreground over the native background.
 * Never intercepts touches.
 */
final class GlassDrawable extends Drawable {
    static final int OVERLAY = 0, INACTIVE = 1, ACTIVE = 2, UNAVAILABLE = 3, CARD = 4;

    private final int kind;
    private final Paint fillBase = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fillGrad = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint rim = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint inner = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint gloss = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();

    private float radiusPx = -1f;   // < 0: derive from bounds
    private float strokePx = 3f;
    private float capPx = 66f;      // max radius for large shapes (cards, sliders, media)
    private float smallPx = 220f;   // ~square shapes at or below this size are round toggles
    private int rimA, innerA, glossA, fillMul = 100, baseA;
    private float angleDeg = 315f;
    private int alpha = 255;

    GlassDrawable() { this(OVERLAY); }

    GlassDrawable(int kind) {
        this.kind = kind;
        rim.setStyle(Paint.Style.STROKE);
        inner.setStyle(Paint.Style.STROKE);
        gloss.setStyle(Paint.Style.FILL);
        fillBase.setStyle(Paint.Style.FILL);
        fillGrad.setStyle(Paint.Style.FILL);
    }

    boolean isOverlay() { return kind == OVERLAY; }

    void update(float radiusPx, float strokePx, float density, GlassStyle s) {
        this.radiusPx = radiusPx;
        this.strokePx = strokePx;
        this.capPx = s.radius * density;
        this.smallPx = 80f * density;
        this.rimA = s.rim * 255 / 100;
        this.innerA = s.inner * 255 / 100;
        this.glossA = s.gloss * 255 / 100;
        this.angleDeg = s.angle;
        this.fillMul = s.fill;
        rebuild();
        invalidateSelf();
    }

    @Override
    protected void onBoundsChange(Rect bounds) {
        rebuild();
    }

    private int mul(int a) { return Math.max(0, Math.min(255, a * fillMul / 100)); }

    private void rebuild() {
        Rect b = getBounds();
        if (b.isEmpty()) return;
        float w = b.width(), h = b.height();
        float cx = b.exactCenterX(), cy = b.exactCenterY();
        double a = Math.toRadians(angleDeg);
        float dx = (float) Math.sin(a), dy = (float) -Math.cos(a); // toward the light
        float ext = (Math.abs(dx) * w + Math.abs(dy) * h) / 2f;
        float x0 = cx + dx * ext, y0 = cy + dy * ext, x1 = cx - dx * ext, y1 = cy - dy * ext;

        if (kind != OVERLAY) {
            int hi, lo;
            switch (kind) {
                case ACTIVE:      baseA = 0;       hi = 0xEE;       lo = 0xCF;       break;
                case UNAVAILABLE: baseA = mul(0x10); hi = mul(0x10); lo = mul(0x06); break;
                case CARD:        baseA = mul(0x30); hi = mul(0x34); lo = mul(0x12); break;
                default:          baseA = mul(0x2E); hi = mul(0x30); lo = mul(0x10); break; // INACTIVE
            }
            fillBase.setColor(Color.argb(baseA, 0, 0, 0));
            fillGrad.setShader(new LinearGradient(x0, y0, x1, y1,
                    Color.argb(hi, 255, 255, 255), Color.argb(lo, 255, 255, 255), Shader.TileMode.CLAMP));
        }

        rim.setStrokeWidth(strokePx);
        rim.setShader(new LinearGradient(x0, y0, x1, y1,
                new int[]{Color.argb(rimA, 255, 255, 255), Color.argb(rimA / 8, 255, 255, 255),
                        Color.argb(rimA * 45 / 100, 255, 255, 255)},
                new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));

        inner.setStrokeWidth(strokePx * 1.6f);
        inner.setShader(new LinearGradient(x0, y0, x1, y1,
                new int[]{Color.argb(innerA, 255, 255, 255), Color.argb(0, 255, 255, 255),
                        Color.argb(innerA / 2, 255, 255, 255)},
                new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));

        gloss.setShader(new LinearGradient(x0, y0, cx, cy,
                Color.argb(glossA, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP));
    }

    @Override
    public void draw(Canvas c) {
        Rect b = getBounds();
        if (b.isEmpty()) return;
        float minDim = Math.min(b.width(), b.height());
        float maxR = minDim / 2f;
        boolean roundToggle = minDim <= smallPx && Math.abs(b.width() - b.height()) < 0.1f * minDim;
        float rad;
        if (roundToggle) rad = radiusPx >= 0 ? Math.min(radiusPx, maxR) : maxR;
        else rad = Math.min(radiusPx >= 0 ? radiusPx : capPx, Math.min(capPx, maxR));

        fillBase.setAlpha(baseA * alpha / 255);
        fillGrad.setAlpha(alpha);
        rim.setAlpha(alpha);
        inner.setAlpha(alpha);
        gloss.setAlpha(alpha);

        float half = strokePx / 2f;
        r.set(b.left + half, b.top + half, b.right - half, b.bottom - half);
        float rr = Math.max(0f, rad - half);
        if (kind != OVERLAY) {
            c.drawRoundRect(r, rr, rr, fillBase);
            c.drawRoundRect(r, rr, rr, fillGrad);
        }
        c.drawRoundRect(r, rr, rr, gloss);
        c.drawRoundRect(r, rr, rr, rim);

        float off = strokePx * 1.9f;
        r.set(b.left + off, b.top + off, b.right - off, b.bottom - off);
        float ri = Math.max(0f, rad - off);
        c.drawRoundRect(r, ri, ri, inner);
    }

    @Override public void setAlpha(int a) { alpha = a; invalidateSelf(); }

    @Override
    public void setColorFilter(ColorFilter cf) {
        fillBase.setColorFilter(cf);
        fillGrad.setColorFilter(cf);
        rim.setColorFilter(cf);
        inner.setColorFilter(cf);
        gloss.setColorFilter(cf);
        invalidateSelf();
    }

    @Override public int getOpacity() { return PixelFormat.TRANSLUCENT; }
}
