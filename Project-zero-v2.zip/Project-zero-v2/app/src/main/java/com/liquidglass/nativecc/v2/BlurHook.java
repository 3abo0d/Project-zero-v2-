package com.liquidglass.nativecc.v2;

import android.content.Context;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;

/**
 * Reduces the Control Center / shade background blur. Hooks BlurUtils.applyBlur(ViewRootImpl, int, boolean)V
 * (signature verified in the SystemUI DEX) and scales the radius by lgcc_v2_blur percent (default 50).
 *   su -c "settings put global lgcc_v2_blur 30"   # 30% of native blur;  100 = unchanged;  0 = no blur
 */
final class BlurHook {
    private static Context appCtx;
    private static long lastLog;
    private static int calls;

    private BlurHook() {}

    private static Context ctx() {
        if (appCtx != null) return appCtx;
        try {
            Class<?> at = Class.forName("android.app.ActivityThread");
            appCtx = (Context) at.getMethod("currentApplication").invoke(null);
        } catch (Throwable t) {
            DebugLogger.e("BlurHook: no app context (blur left unchanged)", t);
        }
        return appCtx;
    }

    static void install(ClassLoader cl) {
        try {
            XposedHelpers.findAndHookMethod("com.android.systemui.statusbar.BlurUtils", cl, "applyBlur",
                    "android.view.ViewRootImpl", int.class, boolean.class, new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam p) {
                    try {
                        int radius = (Integer) p.args[1];
                        Context c = ctx();
                        if (c == null || radius <= 0) return;
                        GlassStyle s = GlassStyle.read(c);
                        if (!s.enabled || s.blur >= 100) return;
                        int scaled = radius * s.blur / 100;
                        p.args[1] = scaled;
                        calls++;
                        long now = System.currentTimeMillis();
                        if (now - lastLog > 1500) {
                            lastLog = now;
                            DebugLogger.i("BLUR applyBlur " + radius + " -> " + scaled + " (" + s.blur + "%) calls=" + calls);
                        }
                    } catch (Throwable t) {
                        DebugLogger.e("blur hook", t);
                    }
                }
            });
            DebugLogger.i("HOOK OK   BlurUtils.applyBlur(ViewRootImpl,int,boolean)");
        } catch (Throwable t) {
            DebugLogger.e("HOOK FAIL BlurUtils.applyBlur", t);
        }
    }
}
