package com.liquidglass.nativecc.v2;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/** LSPosed entry point. Scoped to com.android.systemui only. */
public class V2Entry implements IXposedHookLoadPackage {
    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!"com.android.systemui".equals(lpparam.packageName)) return;
        try {
            DebugLogger.i("loaded in " + lpparam.packageName + " process=" + lpparam.processName);
            QuickSettingsLifecycleHook.install(lpparam.classLoader);
        } catch (Throwable t) {
            DebugLogger.e("lifecycle install failed (stock SystemUI untouched)", t);
        }
        try {
            GlassHooks.install(lpparam.classLoader);
        } catch (Throwable t) {
            DebugLogger.e("glass install failed (stock SystemUI untouched)", t);
        }
    }
}
