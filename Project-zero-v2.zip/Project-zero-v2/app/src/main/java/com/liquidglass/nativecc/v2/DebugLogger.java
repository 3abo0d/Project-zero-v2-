package com.liquidglass.nativecc.v2;

import de.robv.android.xposed.XposedBridge;

/** Every hook registration and lifecycle event goes through here (LSPosed log, tag LGCC-V2). */
final class DebugLogger {
    private static final String TAG = "LGCC-V2: ";
    private DebugLogger() {}
    static void i(String msg) { XposedBridge.log(TAG + msg); }
    static void e(String msg, Throwable t) {
        XposedBridge.log(TAG + "ERROR " + msg);
        if (t != null) XposedBridge.log(t);
    }
}
