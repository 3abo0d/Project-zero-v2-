package com.liquidglass.nativecc.v2;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

/**
 * Reversible prototype attach. Adds ONE small non-clickable pill to the QS root,
 * tagged so it is never duplicated and always removable. Does not touch native children,
 * so native gestures and animations are preserved.
 */
final class PanelController {
    static final String TAG = "lgcc_v2_panel";

    private PanelController() {}

    static void attach(View root) {
        if (!(root instanceof ViewGroup)) {
            DebugLogger.i("attach skipped: root is not a ViewGroup: " + root.getClass().getName());
            return;
        }
        ViewGroup host = (ViewGroup) root;
        if (host.findViewWithTag(TAG) != null) {
            DebugLogger.i("attach skipped: already attached");
            return;
        }
        TextView pill = new TextView(host.getContext());
        pill.setTag(TAG);
        pill.setText("LGCC V2 attached");
        pill.setTextColor(Color.WHITE);
        pill.setTextSize(12f);
        pill.setPadding(32, 12, 32, 12);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0x99000000);
        bg.setCornerRadius(60f);
        pill.setBackground(bg);
        pill.setClickable(false);
        pill.setFocusable(false);
        pill.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);

        ViewGroup.LayoutParams lp;
        if (host instanceof FrameLayout) {
            FrameLayout.LayoutParams f = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            f.gravity = Gravity.TOP | Gravity.END;
            f.topMargin = 120;
            f.rightMargin = 24;
            lp = f;
        } else {
            lp = new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        }
        host.addView(pill, lp);
        DebugLogger.i("ATTACHED to " + host.getClass().getName() + " children=" + host.getChildCount());
    }

    static void detach(View root) {
        if (!(root instanceof ViewGroup)) return;
        ViewGroup host = (ViewGroup) root;
        View v = host.findViewWithTag(TAG);
        while (v != null) {
            ViewGroup parent = (ViewGroup) v.getParent();
            if (parent == null) break;
            parent.removeView(v);
            DebugLogger.i("DETACHED from " + parent.getClass().getName());
            v = host.findViewWithTag(TAG);
        }
    }
}
