package com.liquidglass.nativecc.v2;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

/**
 * Reversible attach of ONE tagged, non-clickable "glass test card" into the real ColorOS
 * Control Center root (OplusQSRootView). It is laid over the native tile area; native views are
 * never removed or reparented, so native gestures and animations are preserved.
 *
 * Optional replacement test (off by default):  settings put global lgcc_v2_hide_tiles 1
 * fades the native tile lists to alpha 0 while the card is attached, and restores them on detach.
 */
final class PanelController {
    static final String TAG = "lgcc_v2_panel";
    private static final String HIDE_KEY = "lgcc_v2_hide_tiles";
    private static final String SYSTEMUI = "com.android.systemui";
    private static final String TILE_AREA = "other_tiles_container";
    private static final String[] TILE_IDS = {"personal_tiles_container", "other_tiles_container"};
    private static final String[] GEOM_IDS = {
            "qs_container_area_layout", "qs_status_bar_container_layout", "qs_quick_entrance_container",
            "personal_tiles_container", "other_tiles_container", "qs_bottom_area_layout",
            "qs_page_indicator_container", "oplus_qs_add_tile_panel"};

    private static boolean tilesHidden;

    private PanelController() {}

    private static int dp(Context c, float v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, c.getResources().getDisplayMetrics());
    }

    private static View find(ViewGroup host, String name) {
        try {
            int id = host.getResources().getIdentifier(name, "id", SYSTEMUI);
            return id == 0 ? null : host.findViewById(id);
        } catch (Throwable t) {
            return null;
        }
    }

    /** left/top/width/height of v inside root, ignoring animation translation; null if not a descendant. */
    private static int[] rectIn(View v, View root) {
        if (v == null) return null;
        int l = 0, t = 0;
        View cur = v;
        while (cur != root) {
            l += cur.getLeft();
            t += cur.getTop();
            if (!(cur.getParent() instanceof View)) return null;
            cur = (View) cur.getParent();
        }
        return new int[]{l, t, v.getWidth(), v.getHeight()};
    }

    private static boolean hideRequested(Context c) {
        try {
            return Settings.Global.getInt(c.getContentResolver(), HIDE_KEY, 0) == 1;
        } catch (Throwable t) {
            return false;
        }
    }

    private static void applyHide(ViewGroup host) {
        boolean want = hideRequested(host.getContext());
        if (want == tilesHidden) return;
        for (String id : TILE_IDS) {
            View v = find(host, id);
            if (v != null) v.setAlpha(want ? 0f : 1f);
        }
        tilesHidden = want;
        DebugLogger.i("native tiles " + (want ? "HIDDEN (alpha 0)" : "RESTORED (alpha 1)"));
    }

    private static FrameLayout.LayoutParams boundsFor(ViewGroup host) {
        Context c = host.getContext();
        int[] r = rectIn(find(host, TILE_AREA), host);
        FrameLayout.LayoutParams lp;
        if (r != null && r[2] > 0 && r[3] > 0) {
            lp = new FrameLayout.LayoutParams(r[2], r[3]);
            lp.leftMargin = r[0];
            lp.topMargin = r[1];
        } else {
            lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(c, 220));
            lp.leftMargin = dp(c, 16);
            lp.rightMargin = dp(c, 16);
            lp.topMargin = dp(c, 170);
        }
        lp.gravity = Gravity.TOP | Gravity.START;
        return lp;
    }

    static void attach(View root) {
        if (!(root instanceof ViewGroup)) {
            DebugLogger.i("attach skipped: root is not a ViewGroup: " + root.getClass().getName());
            return;
        }
        ViewGroup host = (ViewGroup) root;
        try {
            if (Settings.Global.getInt(host.getContext().getContentResolver(), "lgcc_v2_card", 0) != 1) return;
        } catch (Throwable t) {
            return;
        }
        if (!(host instanceof FrameLayout)) {
            DebugLogger.i("attach skipped: host is not a FrameLayout: " + host.getClass().getName());
            return;
        }
        if (host.findViewWithTag(TAG) != null) {
            applyHide(host);
            return;
        }
        Context c = host.getContext();
        FrameLayout card = new FrameLayout(c);
        card.setTag(TAG);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0x33FFFFFF);
        bg.setStroke(dp(c, 1), 0x66FFFFFF);
        bg.setCornerRadius(dp(c, 28));
        card.setBackground(bg);
        card.setClickable(false);
        card.setFocusable(false);
        card.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        TextView label = new TextView(c);
        label.setText("LGCC V2 glass card (test)");
        label.setTextColor(0xFFFFFFFF);
        label.setTextSize(13f);
        card.addView(label, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));
        host.addView(card, boundsFor(host));
        DebugLogger.i("ATTACHED card to " + host.getClass().getName() + " children=" + host.getChildCount());
        applyHide(host);
    }

    /** Called once per open when fully expanded, when native views have real sizes. */
    static void relayout(View root) {
        try {
            if (!(root instanceof ViewGroup)) return;
            ViewGroup host = (ViewGroup) root;
            View card = host.findViewWithTag(TAG);
            if (card == null) return;
            card.setLayoutParams(boundsFor(host));
            card.requestLayout();
            DebugLogger.i("RELAYOUT card to native tile area");
        } catch (Throwable t) {
            DebugLogger.e("relayout", t);
        }
    }

    static void logGeometry(View root) {
        try {
            if (!(root instanceof ViewGroup)) return;
            ViewGroup host = (ViewGroup) root;
            DebugLogger.i("GEOM root " + host.getWidth() + "x" + host.getHeight());
            for (String id : GEOM_IDS) {
                View v = find(host, id);
                if (v == null) { DebugLogger.i("GEOM " + id + " = not found"); continue; }
                int[] r = rectIn(v, host);
                String extra = v instanceof ViewGroup ? " children=" + ((ViewGroup) v).getChildCount() : "";
                DebugLogger.i("GEOM " + id + " " + v.getClass().getSimpleName()
                        + (r == null ? " (not in root)" : " l=" + r[0] + " t=" + r[1] + " w=" + r[2] + " h=" + r[3])
                        + " vis=" + v.getVisibility() + " alpha=" + v.getAlpha() + extra);
            }
        } catch (Throwable t) {
            DebugLogger.e("logGeometry", t);
        }
    }

    static void detach(View root) {
        if (!(root instanceof ViewGroup)) return;
        ViewGroup host = (ViewGroup) root;
        if (tilesHidden) {
            for (String id : TILE_IDS) {
                View v = find(host, id);
                if (v != null) v.setAlpha(1f);
            }
            tilesHidden = false;
            DebugLogger.i("native tiles RESTORED on detach");
        }
        View v = host.findViewWithTag(TAG);
        while (v != null) {
            ViewGroup parent = (ViewGroup) v.getParent();
            if (parent == null) break;
            parent.removeView(v);
            DebugLogger.i("DETACHED from " + parent.getClass().getName());
            v = host.findViewWithTag(TAG);
        }
    }
}
