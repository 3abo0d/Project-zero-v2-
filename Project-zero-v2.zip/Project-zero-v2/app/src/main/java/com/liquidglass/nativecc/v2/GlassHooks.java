package com.liquidglass.nativecc.v2;

import android.content.Context;
import android.graphics.Outline;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewOutlineProvider;

import java.util.HashSet;
import java.util.Set;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;

/**
 * Probe 5: glass material on the NATIVE Control Center views. Hook targets verified in the
 * real SystemUI 16.00.14 DEX:
 *   QsTileFluidGlassBackground   field qsTileView (QsTileViewInfoProvider).getBackgroundView()
 *   QsStaticFluidGlassBackground field panelInfo  (QsStaticViewInfoProvider).getBackgroundView()
 *   OplusToggleSliderView / OplusQsBaseToggleSliderLayout .onAttachedToWindow()
 */
final class GlassHooks {
    private static final String TILE = "com.oplus.systemui.qs.base.widget.QsTileFluidGlassBackground";
    private static final String STATIC = "com.oplus.systemui.qs.base.widget.QsStaticFluidGlassBackground";
    private static final String SLIDER_VIEW = "com.oplus.systemui.qs.widget.OplusToggleSliderView";
    private static final String SLIDER_LAYOUT = "com.oplus.systemui.qs.base.seek.OplusQsBaseToggleSliderLayout";

    private static final String RES_UTIL = "com.oplus.systemui.qs.base.util.FluidGlassResourceUtil";

    private static final Set<String> logged = new HashSet<>();
    private static int applied;

    private GlassHooks() {}

    static void install(ClassLoader cl) {
        // REPLACE native baked glass bitmaps: central factory FluidGlassResourceUtil.getFluidGlassBg(Context,int)
        hook(cl, RES_UTIL, "getFluidGlassBg", Context.class, int.class, replaceBg());
        hook(cl, TILE, "onBackgroundAttach", viaField("qsTileView", "TILE"));
        hook(cl, TILE, "refreshViewBackground", viaField("qsTileView", "TILE"));
        hook(cl, TILE, "updateBackground", int.class, boolean.class, boolean.class, viaField("qsTileView", "TILE"));
        hook(cl, TILE, "updateBackground", int.class, viaField("qsTileView", "TILE"));
        hook(cl, STATIC, "onBackgroundAttach", viaField("panelInfo", "STATIC"));
        hook(cl, STATIC, "refreshViewBackground", viaField("panelInfo", "STATIC"));
        hook(cl, SLIDER_VIEW, "onAttachedToWindow", selfView("SLIDER_VIEW"));
        hook(cl, SLIDER_LAYOUT, "onAttachedToWindow", selfView("SLIDER_LAYOUT"));
    }

    private static void hook(ClassLoader cl, String cls, String method, Object... typesAndCallback) {
        String name = cls.substring(cls.lastIndexOf('.') + 1) + "." + method;
        try {
            XposedHelpers.findAndHookMethod(cls, cl, method, typesAndCallback);
            DebugLogger.i("GLASS HOOK OK   " + name);
        } catch (Throwable t) {
            DebugLogger.e("GLASS HOOK FAIL " + name, t);
        }
    }

    private static XC_MethodHook viaField(final String field, final String tag) {
        return new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam p) {
                try {
                    Object provider = XposedHelpers.getObjectField(p.thisObject, field);
                    if (provider == null) return;
                    View host = (View) XposedHelpers.callMethod(provider, "getBackgroundView");
                    apply(host, tag);
                } catch (Throwable t) {
                    DebugLogger.e("glass viaField " + tag, t);
                }
            }
        };
    }

    private static int kindFor(String name) {
        if (!name.endsWith("fluid_glass_bg")) return -1;       // skip icons and other assets
        if (name.contains("flashlight")) return -1;             // leave flashlight brightness art native
        if (name.contains("unavailable")) return GlassDrawable.UNAVAILABLE;
        if (name.contains("inactive")) return GlassDrawable.INACTIVE;
        if (name.contains("active")) return GlassDrawable.ACTIVE;
        return GlassDrawable.CARD;                              // media, entrance, device cards, sliders, etc.
    }

    private static XC_MethodHook replaceBg() {
        return new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam p) {
                try {
                    Context ctx = (Context) p.args[0];
                    int id = (Integer) p.args[1];
                    String name;
                    try { name = ctx.getResources().getResourceEntryName(id); }
                    catch (Throwable t) { name = "?" + id; }
                    Object orig = p.getResult();
                    int kind = kindFor(name);
                    if (logged.add("res-" + name)) {
                        DebugLogger.i("GLASS RES " + name + " native="
                                + (orig == null ? "null" : orig.getClass().getSimpleName()) + " kind=" + kind);
                    }
                    GlassStyle s = GlassStyle.read(ctx);
                    if (!s.enabled || !s.replace || kind < 0) return;
                    float density = ctx.getResources().getDisplayMetrics().density;
                    GlassDrawable g = new GlassDrawable(kind);
                    g.update(-1f, s.width / 10f * density, density, s);
                    p.setResult(g);
                } catch (Throwable t) {
                    DebugLogger.e("replaceBg (native drawable kept)", t);
                }
            }
        };
    }

    private static XC_MethodHook selfView(final String tag) {
        return new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam p) {
                try {
                    apply((View) p.thisObject, tag);
                } catch (Throwable t) {
                    DebugLogger.e("glass selfView " + tag, t);
                }
            }
        };
    }

    private static float outlineRadius(View v) {
        try {
            ViewOutlineProvider op = v.getOutlineProvider();
            if (op == null || v.getWidth() == 0 || v.getHeight() == 0) return -1f;
            Outline o = new Outline();
            op.getOutline(v, o);
            float r = o.getRadius();
            return r >= 0 ? r : -1f;
        } catch (Throwable t) {
            return -1f;
        }
    }

    static void apply(View v, String tag) {
        if (v == null) return;
        Context c = v.getContext();
        GlassStyle s = GlassStyle.read(c);
        Drawable cur = v.getForeground();
        if (s.enabled && s.replace) {
            // replacement mode: our material IS the background; drop any old overlay layer
            if (cur instanceof GlassDrawable && ((GlassDrawable) cur).isOverlay()) v.setForeground(null);
            return;
        }
        if (!s.enabled) {
            if (cur instanceof GlassDrawable) v.setForeground(null);
            return;
        }
        GlassDrawable g;
        if (cur instanceof GlassDrawable) {
            g = (GlassDrawable) cur;
        } else if (cur == null) {
            g = new GlassDrawable();
            v.setForeground(g);
            applied++;
            if (logged.add("new-" + tag + "-" + v.getClass().getName())) {
                DebugLogger.i("GLASS applied [" + tag + "] to " + v.getClass().getName()
                        + " size=" + v.getWidth() + "x" + v.getHeight() + " total=" + applied);
            }
        } else {
            if (logged.add("occ-" + tag + "-" + v.getClass().getName())) {
                DebugLogger.i("GLASS skipped [" + tag + "]: foreground already "
                        + cur.getClass().getName() + " on " + v.getClass().getName());
            }
            return;
        }
        float density = c.getResources().getDisplayMetrics().density;
        float outR = outlineRadius(v);
        if (logged.add("r-" + tag + "-" + v.getClass().getName())) {
            DebugLogger.i("GLASS radius [" + tag + "] " + v.getClass().getSimpleName() + " outlineR=" + outR
                    + " size=" + v.getWidth() + "x" + v.getHeight());
        }
        g.update(outR, s.width / 10f * density, density, s);
    }
}
