package com.liquidglass.nativecc.v2;

import android.content.Context;
import android.provider.Settings;

/**
 * Live-tunable look parameters, read from Settings.Global (no rebuild needed):
 *   settings put global lgcc_v2_glass 0|1        master switch (default 1)
 *   settings put global lgcc_v2_rim 0..100       edge-light strength (default 60)
 *   settings put global lgcc_v2_inner 0..100     inner refraction-band strength (default 16)
 *   settings put global lgcc_v2_gloss 0..100     top gloss strength (default 20)
 *   settings put global lgcc_v2_width 1..60      rim width in 0.1 dp (default 12)
 *   settings put global lgcc_v2_angle 0..359     light direction, 0=top, 90=right (default 315 = top-left)
 * Changes apply the next time a tile/slider refreshes (close and reopen the Control Center).
 */
final class GlassStyle {
    boolean enabled = true;
    int rim = 60, inner = 16, gloss = 20, width = 12, angle = 315;

    private static GlassStyle cached;
    private static long cachedAt;

    static synchronized GlassStyle read(Context c) {
        long now = System.currentTimeMillis();
        if (cached != null && now - cachedAt < 400) return cached;
        GlassStyle s = new GlassStyle();
        try {
            android.content.ContentResolver r = c.getContentResolver();
            s.enabled = Settings.Global.getInt(r, "lgcc_v2_glass", 1) == 1
                    && Settings.Global.getInt(r, "lgcc_v2_disable", 0) != 1;
            s.rim = clamp(Settings.Global.getInt(r, "lgcc_v2_rim", s.rim), 0, 100);
            s.inner = clamp(Settings.Global.getInt(r, "lgcc_v2_inner", s.inner), 0, 100);
            s.gloss = clamp(Settings.Global.getInt(r, "lgcc_v2_gloss", s.gloss), 0, 100);
            s.width = clamp(Settings.Global.getInt(r, "lgcc_v2_width", s.width), 1, 60);
            s.angle = clamp(Settings.Global.getInt(r, "lgcc_v2_angle", s.angle), 0, 359);
        } catch (Throwable t) {
            DebugLogger.e("GlassStyle.read (using defaults)", t);
        }
        cached = s;
        cachedAt = now;
        return s;
    }

    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }
}
