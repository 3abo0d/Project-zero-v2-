package com.liquidglass.nativecc.v2;

import android.content.Context;
import android.provider.Settings;

/**
 * Live-tunable look parameters, read from Settings.Global (no rebuild needed):
 *   lgcc_v2_glass   0|1       master switch (default 1)
 *   lgcc_v2_replace 0|1       1 = REPLACE the native baked glass bitmaps with our material (default 1)
 *                             0 = old overlay mode (our edge layer on top of native)
 *   lgcc_v2_blur    0..100    panel background blur strength in percent of native (default 50)
 *   lgcc_v2_fill    0..200    body fill strength of inactive tiles/cards, percent (default 100)
 *   lgcc_v2_rim     0..100    edge-light strength (default 60)
 *   lgcc_v2_inner   0..100    inner refraction band strength (default 16)
 *   lgcc_v2_gloss   0..100    top gloss strength (default 20)
 *   lgcc_v2_width   1..60     rim width in 0.1 dp (default 12)
 *   lgcc_v2_radius  4..80     max corner radius dp for cards/sliders/media (default 24)
 *   lgcc_v2_angle   0..359    light direction, 0=top, 90=right (default 315 = top-left)
 * Tile/slider changes apply the next time the Control Center is reopened.
 */
final class GlassStyle {
    boolean enabled = true;
    boolean replace = true;
    int rim = 60, inner = 16, gloss = 20, width = 12, angle = 315, radius = 24, fill = 100, blur = 50;

    private static GlassStyle cached;
    private static long cachedAt;

    static synchronized GlassStyle read(Context c) {
        long now = System.currentTimeMillis();
        if (cached != null && now - cachedAt < 400) return cached;
        GlassStyle s = new GlassStyle();
        try {
            android.content.ContentResolver r = c.getContentResolver();
            s.enabled = Settings.Global.getInt(r, "lgcc_v2_glass", 1) == 1
                    && Settings.Global.getInt(r, "lgcc_v2_disable", 0) != 1;
            s.replace = Settings.Global.getInt(r, "lgcc_v2_replace", 1) == 1;
            s.blur = clamp(Settings.Global.getInt(r, "lgcc_v2_blur", s.blur), 0, 100);
            s.fill = clamp(Settings.Global.getInt(r, "lgcc_v2_fill", s.fill), 0, 200);
            s.rim = clamp(Settings.Global.getInt(r, "lgcc_v2_rim", s.rim), 0, 100);
            s.inner = clamp(Settings.Global.getInt(r, "lgcc_v2_inner", s.inner), 0, 100);
            s.gloss = clamp(Settings.Global.getInt(r, "lgcc_v2_gloss", s.gloss), 0, 100);
            s.width = clamp(Settings.Global.getInt(r, "lgcc_v2_width", s.width), 1, 60);
            s.angle = clamp(Settings.Global.getInt(r, "lgcc_v2_angle", s.angle), 0, 359);
            s.radius = clamp(Settings.Global.getInt(r, "lgcc_v2_radius", s.radius), 4, 80);
        } catch (Throwable t) {
            DebugLogger.e("GlassStyle.read (using defaults)", t);
        }
        cached = s;
        cachedAt = now;
        return s;
    }

    private static int clamp(int v, int lo, int hi) { return Math.max(lo, Math.min(hi, v)); }
}
