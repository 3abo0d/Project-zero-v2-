package com.liquidglass.nativecc.v2;

import android.content.Context;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;

import java.lang.ref.WeakReference;
import java.util.HashSet;
import java.util.Set;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;

/**
 * Probe 2. Every hook target below was verified to exist in the real SystemUI 16.00.14 DEX
 * (parsed from systemui.apk). Log-only except the reversible tagged pill from PanelController.
 * Whichever lifecycle path ColorOS really uses will show up in the log.
 */
final class QuickSettingsLifecycleHook {
    private static final String DISABLE_KEY = "lgcc_v2_disable"; // settings put global lgcc_v2_disable 1

    private static final String QS_IMPL = "com.android.systemui.qs.QSImpl";
    private static final String QS_LEGACY = "com.android.systemui.qs.QSFragmentLegacy";
    private static final String QS_COMPOSE = "com.android.systemui.qs.composefragment.QSFragmentCompose";
    private static final String QS_CONTAINER = "com.android.systemui.qs.QSContainerImpl";
    private static final String OPLUS_CONTAINER = "com.oplus.systemui.qs.OplusQSContainerImpl";
    private static final String OPLUS_PANEL = "com.oplus.systemui.qs.OplusQSPanelContainer";
    private static final String SHADE_QS_CTRL = "com.android.systemui.shade.QuickSettingsControllerImpl";

    // ColorOS "separate QS" = the Control Center. Verified in the DEX:
    private static final String PAGER_CTRL = "com.oplus.systemui.separate.OplusPanelViewPagerController";
    private static final String SEP_EX = "com.oplus.systemui.separate.OplusSeparateNotificationAndQSExImpl";
    private static final String SEP_QS_MGR = "com.oplus.systemui.separate.OplusSeparateQSManager";
    private static final String SIMPLE_QS = "com.oplus.systemui.separate.OplusSimpleQSFragment";

    private static boolean qsShown;
    private static final long THROTTLE_MS = 700;
    private static final Set<String> dumped = new HashSet<>();
    private static final java.util.Map<String, Long> lastLog = new java.util.HashMap<>();
    private static WeakReference<ViewGroup> lastHost = new WeakReference<>(null);

    private QuickSettingsLifecycleHook() {}

    static void install(ClassLoader cl) {
        // view-inflate hooks (also dump the real view tree once per class)
        hook(cl, QS_CONTAINER, "onFinishInflate", inflate("QSContainerImpl"));
        hook(cl, OPLUS_CONTAINER, "onFinishInflate", inflate("OplusQSContainerImpl"));
        hook(cl, OPLUS_PANEL, "onFinishInflate", inflate("OplusQSPanelContainer"));

        // fragment/impl expand callbacks: they can provide the root view via getView()
        hook(cl, QS_IMPL, "setExpanded", boolean.class, expanded("QSImpl", true));
        hook(cl, QS_LEGACY, "setExpanded", boolean.class, expanded("QSFragmentLegacy", true));
        hook(cl, QS_COMPOSE, "setExpanded", boolean.class, expanded("QSFragmentCompose", true));
        // shade-level controller: no view, uses the last remembered host
        hook(cl, SHADE_QS_CTRL, "setExpanded", boolean.class, expanded("QuickSettingsControllerImpl", false));

        // ColorOS separate Control Center path (verified signatures)
        hook(cl, PAGER_CTRL, "onViewAttached", logOnly("PagerController.onViewAttached"));
        hook(cl, PAGER_CTRL, "loadQSPanelView", boolean.class, loadQs());
        hook(cl, PAGER_CTRL, "updateQSExpandFraction", float.class, boolean.class, boolean.class, float.class, qsFraction());
        hook(cl, PAGER_CTRL, "updateNotifyExpandFraction", float.class, boolean.class, progress("Pager.updateNotifyExpandFraction"));
        hook(cl, PAGER_CTRL, "onSeparateNotifyExpandChange", boolean.class, logOnly("Pager.onSeparateNotifyExpandChange"));
        hook(cl, SEP_EX, "expandQSPanel", logOnly("SeparateEx.expandQSPanel"));
        hook(cl, SEP_EX, "collapseQSPanel", boolean.class, boolean.class, boolean.class, logOnly("SeparateEx.collapseQSPanel"));
        hook(cl, SEP_QS_MGR, "expandQSPanel", boolean.class, logOnly("SeparateQSManager.expandQSPanel"));
        hook(cl, SIMPLE_QS, "setExpanded", boolean.class, expanded("OplusSimpleQSFragment", true));
        hook(cl, SIMPLE_QS, "setQsVisible", boolean.class, logOnly("OplusSimpleQSFragment.setQsVisible"));
        hook(cl, SIMPLE_QS, "setQsExpansion", float.class, float.class, float.class, float.class, progress("OplusSimpleQSFragment.setQsExpansion"));
        hook(cl, SIMPLE_QS, "onViewCreated", View.class, android.os.Bundle.class, viewCreated("OplusSimpleQSFragment"));

        // expansion progress (throttled logging only)
        hook(cl, QS_IMPL, "setQsExpansion", float.class, float.class, float.class, float.class, progress("QSImpl.setQsExpansion"));
        hook(cl, QS_LEGACY, "setQsExpansion", float.class, float.class, float.class, float.class, progress("QSFragmentLegacy.setQsExpansion"));
        hook(cl, QS_COMPOSE, "setQsExpansion", float.class, float.class, float.class, float.class, progress("QSFragmentCompose.setQsExpansion"));
        hook(cl, SHADE_QS_CTRL, "setExpansionHeight", float.class, progress("QuickSettingsControllerImpl.setExpansionHeight"));
    }

    private static void hook(ClassLoader cl, String cls, String method, Object... typesAndCallback) {
        String name = cls.substring(cls.lastIndexOf('.') + 1) + "." + method;
        try {
            XposedHelpers.findAndHookMethod(cls, cl, method, typesAndCallback);
            DebugLogger.i("HOOK OK   " + name);
        } catch (Throwable t) {
            DebugLogger.e("HOOK FAIL " + name, t);
        }
    }

    private static boolean disabled(View v) {
        try {
            Context c = v.getContext();
            return Settings.Global.getInt(c.getContentResolver(), DISABLE_KEY, 0) == 1;
        } catch (Throwable t) {
            return false;
        }
    }

    private static boolean throttled(String key) {
        long now = System.currentTimeMillis();
        Long last = lastLog.get(key);
        if (last != null && now - last < THROTTLE_MS) return true;
        lastLog.put(key, now);
        return false;
    }

    private static XC_MethodHook inflate(final String label) {
        return new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam p) {
                try {
                    View v = (View) p.thisObject;
                    DebugLogger.i("INFLATE " + label + " view=" + v.getClass().getName()
                            + " children=" + (v instanceof ViewGroup ? ((ViewGroup) v).getChildCount() : 0));
                    if (v instanceof ViewGroup && !label.equals("OplusQSPanelContainer")) {
                        lastHost = new WeakReference<>((ViewGroup) v);
                    }
                    if (dumped.add(label)) ViewTreeDumper.dump(v, label);
                } catch (Throwable t) {
                    DebugLogger.e("inflate hook " + label, t);
                }
            }
        };
    }

    private static XC_MethodHook expanded(final String label, final boolean hasView) {
        return new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam p) {
                try {
                    boolean exp = (Boolean) p.args[0];
                    DebugLogger.i("EXPANDED " + label + ".setExpanded(" + exp + ")");
                    View root = null;
                    if (hasView) {
                        try { root = (View) XposedHelpers.callMethod(p.thisObject, "getView"); }
                        catch (Throwable t) { DebugLogger.i(label + ".getView() unavailable: " + t); }
                    }
                    if (root == null) root = lastHost.get();
                    if (root == null) {
                        DebugLogger.i(label + ": no host view available yet");
                        return;
                    }
                    if (dumped.add("root-" + label)) ViewTreeDumper.dump(root, "root-" + label);
                    if (disabled(root) || !exp) PanelController.detach(root);
                    else PanelController.attach(root);
                } catch (Throwable t) {
                    DebugLogger.e("expanded hook " + label, t);
                }
            }
        };
    }

    private static XC_MethodHook progress(final String label) {
        return new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam p) {
                try {
                    if (throttled(label)) return;
                    StringBuilder sb = new StringBuilder("PROGRESS " + label);
                    for (Object a : p.args) sb.append(' ').append(a);
                    DebugLogger.i(sb.toString());
                } catch (Throwable t) {
                    DebugLogger.e("progress hook " + label, t);
                }
            }
        };
    }

    private static XC_MethodHook logOnly(final String label) {
        return new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam p) {
                try {
                    StringBuilder sb = new StringBuilder("CALL " + label);
                    if (p.args != null) for (Object a : p.args) sb.append(' ').append(a);
                    DebugLogger.i(sb.toString());
                } catch (Throwable t) {
                    DebugLogger.e("logOnly " + label, t);
                }
            }
        };
    }

    private static View qsPanelOf(Object controller) {
        try { return (View) XposedHelpers.callMethod(controller, "getQSPanelView"); }
        catch (Throwable t) { return null; }
    }

    private static XC_MethodHook loadQs() {
        return new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam p) {
                try {
                    View qs = qsPanelOf(p.thisObject);
                    DebugLogger.i("CALL Pager.loadQSPanelView(" + p.args[0] + ") qsPanel="
                            + (qs == null ? "null" : qs.getClass().getName()));
                    if (qs instanceof ViewGroup) {
                        lastHost = new WeakReference<>((ViewGroup) qs);
                        if (dumped.add("qs-panel")) ViewTreeDumper.dump(qs, "qs-panel");
                    }
                } catch (Throwable t) {
                    DebugLogger.e("loadQs hook", t);
                }
            }
        };
    }

    private static XC_MethodHook viewCreated(final String label) {
        return new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam p) {
                try {
                    View v = (View) p.args[0];
                    DebugLogger.i("VIEWCREATED " + label + " view=" + (v == null ? "null" : v.getClass().getName()));
                    if (v != null && dumped.add("created-" + label)) ViewTreeDumper.dump(v, "created-" + label);
                } catch (Throwable t) {
                    DebugLogger.e("viewCreated hook", t);
                }
            }
        };
    }

    /** Pager.updateQSExpandFraction(fraction, bool, bool, float): drives attach/detach on the real Control Center view. */
    private static XC_MethodHook qsFraction() {
        return new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam p) {
                try {
                    float f = (Float) p.args[0];
                    if (!throttled("Pager.updateQSExpandFraction")) {
                        DebugLogger.i("PROGRESS Pager.updateQSExpandFraction " + p.args[0] + " " + p.args[1]
                                + " " + p.args[2] + " " + p.args[3]);
                    }
                    View qs = qsPanelOf(p.thisObject);
                    if (qs == null) qs = lastHost.get();
                    if (qs == null) return;
                    boolean show = f > 0.05f && !disabled(qs);
                    if (show != qsShown) {
                        qsShown = show;
                        DebugLogger.i("QS SHOWN=" + show + " (fraction " + f + ") host=" + qs.getClass().getName());
                        if (show) PanelController.attach(qs); else PanelController.detach(qs);
                    }
                } catch (Throwable t) {
                    DebugLogger.e("qsFraction hook", t);
                }
            }
        };
    }
}
