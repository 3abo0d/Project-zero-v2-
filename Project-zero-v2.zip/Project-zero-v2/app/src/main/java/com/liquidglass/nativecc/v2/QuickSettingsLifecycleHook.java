package com.liquidglass.nativecc.v2;

import android.content.Context;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedHelpers;

/**
 * Hooks ONLY methods verified in the real SystemUI 16.00.14 DEX (parsed from systemui.apk):
 *   com.android.systemui.qs.QSImpl.setExpanded(Z)V
 *   com.android.systemui.qs.QSImpl.setQsExpansion(FFFF)V
 *   com.android.systemui.qs.QSImpl.getView()Landroid/view/View;
 *   com.android.systemui.qs.QSContainerImpl.onFinishInflate()V   (extends FrameLayout)
 * Every hook is wrapped so an exception can never propagate into SystemUI.
 */
final class QuickSettingsLifecycleHook {
    private static final String QS_IMPL = "com.android.systemui.qs.QSImpl";
    private static final String QS_CONTAINER = "com.android.systemui.qs.QSContainerImpl";
    private static final String DISABLE_KEY = "lgcc_v2_disable"; // settings put global lgcc_v2_disable 1

    private static long lastExpansionLog;
    private static boolean treeDumped;

    private QuickSettingsLifecycleHook() {}

    static void install(ClassLoader cl) {
        hookContainerInflate(cl);
        hookSetExpanded(cl);
        hookSetQsExpansion(cl);
    }

    private static boolean disabled(View v) {
        try {
            Context c = v.getContext();
            return Settings.Global.getInt(c.getContentResolver(), DISABLE_KEY, 0) == 1;
        } catch (Throwable t) {
            return false;
        }
    }

    private static void hookContainerInflate(ClassLoader cl) {
        try {
            XposedHelpers.findAndHookMethod(QS_CONTAINER, cl, "onFinishInflate", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam p) {
                    try {
                        DebugLogger.i("QSContainerImpl.onFinishInflate view=" + p.thisObject);
                    } catch (Throwable t) {
                        DebugLogger.e("onFinishInflate hook", t);
                    }
                }
            });
            DebugLogger.i("HOOK OK   QSContainerImpl.onFinishInflate()V");
        } catch (Throwable t) {
            DebugLogger.e("HOOK FAIL QSContainerImpl.onFinishInflate()V", t);
        }
    }

    private static void hookSetExpanded(ClassLoader cl) {
        try {
            XposedHelpers.findAndHookMethod(QS_IMPL, cl, "setExpanded", boolean.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam p) {
                    try {
                        boolean expanded = (Boolean) p.args[0];
                        DebugLogger.i("QSImpl.setExpanded(" + expanded + ")");
                        View root = (View) XposedHelpers.callMethod(p.thisObject, "getView");
                        if (root == null) {
                            DebugLogger.i("QSImpl.getView() returned null");
                            return;
                        }
                        if (!treeDumped) {
                            treeDumped = true;
                            ViewTreeDumper.dump(root);
                        }
                        if (disabled(root)) {
                            PanelController.detach(root);
                            return;
                        }
                        if (expanded) PanelController.attach(root);
                        else PanelController.detach(root);
                    } catch (Throwable t) {
                        DebugLogger.e("setExpanded hook", t);
                    }
                }
            });
            DebugLogger.i("HOOK OK   QSImpl.setExpanded(Z)V");
        } catch (Throwable t) {
            DebugLogger.e("HOOK FAIL QSImpl.setExpanded(Z)V", t);
        }
    }

    private static void hookSetQsExpansion(ClassLoader cl) {
        try {
            XposedHelpers.findAndHookMethod(QS_IMPL, cl, "setQsExpansion",
                    float.class, float.class, float.class, float.class, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam p) {
                    try {
                        long now = System.currentTimeMillis();
                        if (now - lastExpansionLog < 700) return; // throttle
                        lastExpansionLog = now;
                        DebugLogger.i("QSImpl.setQsExpansion exp=" + p.args[0]
                                + " panelExp=" + p.args[1] + " transY=" + p.args[2] + " squish=" + p.args[3]);
                    } catch (Throwable t) {
                        DebugLogger.e("setQsExpansion hook", t);
                    }
                }
            });
            DebugLogger.i("HOOK OK   QSImpl.setQsExpansion(FFFF)V");
        } catch (Throwable t) {
            DebugLogger.e("HOOK FAIL QSImpl.setQsExpansion(FFFF)V", t);
        }
    }
}
