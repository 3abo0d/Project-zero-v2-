plugins { id("com.android.application") }

android {
    namespace = "com.liquidglass.nativecc.v2"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.liquidglass.nativecc.v2"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "2.0.0-probe1"
    }
    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    // Xposed API stubs: compile-time only, NOT packaged into the APK.
    compileOnly(project(":xposed-stub"))
}
