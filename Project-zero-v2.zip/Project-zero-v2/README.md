# LiquidGlassCC V2 — Quick Settings attach probe

LSPosed module, scope: com.android.systemui ONLY. Separate from your working Fluid Glass module
(keep that one enabled; this one does not touch Fluid Glass).

Hooks (all signatures verified in the real SystemUI 16.00.14 DEX):
- QSImpl.setExpanded(Z)V, QSImpl.setQsExpansion(FFFF)V, QSImpl.getView()View
- QSContainerImpl.onFinishInflate()V

Kill switch (no reboot of module needed after next shade open):
  su -c "settings put global lgcc_v2_disable 1"     # off
  su -c "settings put global lgcc_v2_disable 0"     # on
Logs: LSPosed manager -> Logs, search "LGCC-V2". View tree: /data/user/0/com.android.systemui/files/lgcc_v2_viewtree_<label>.txt

Probe 4: glass test card over the native tile area. Optional replacement test:
  su -c "settings put global lgcc_v2_hide_tiles 1"   # native tiles alpha 0 while card shown
  su -c "settings put global lgcc_v2_hide_tiles 0"   # restore

Probe 5: glass material (rim light, inner refraction band, gloss) as a View foreground on native tiles,
sliders and cards. Tune live (then close/reopen the Control Center):
  settings put global lgcc_v2_glass 0|1   lgcc_v2_rim 0-100   lgcc_v2_inner 0-100
  settings put global lgcc_v2_gloss 0-100   lgcc_v2_width 1-60 (0.1dp)   lgcc_v2_angle 0-359
The old test card is now opt-in: settings put global lgcc_v2_card 1
