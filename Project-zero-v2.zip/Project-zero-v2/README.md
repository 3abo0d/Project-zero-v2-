# LiquidGlassCC V2 — Quick Settings attach probe

LSPosed module, scope: com.android.systemui ONLY. Separate from your working Fluid Glass module
(keep that one enabled; this one does not touch Fluid Glass).

Hooks (all signatures verified in the real SystemUI 16.00.14 DEX):
- QSImpl.setExpanded(Z)V, QSImpl.setQsExpansion(FFFF)V, QSImpl.getView()View
- QSContainerImpl.onFinishInflate()V

Kill switch (no reboot of module needed after next shade open):
  su -c "settings put global lgcc_v2_disable 1"     # off
  su -c "settings put global lgcc_v2_disable 0"     # on
Logs: LSPosed manager -> Logs, search "LGCC-V2". View tree: /data/user/0/com.android.systemui/files/lgcc_v2_viewtree.txt
